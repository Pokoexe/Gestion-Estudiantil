import { createBrowserRouter } from "react-router";
import { LoginPage } from "./pages/LoginPage";
import { AppLayout } from "./components/AppLayout";
import { DashboardPage } from "./pages/DashboardPage";
import { CoursesPage } from "./pages/CoursesPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LoginPage,
  },
  {
    path: "/dashboard",
    Component: AppLayout,
    children: [
      { index: true, Component: DashboardPage },
      { path: "courses", Component: CoursesPage },
    ],
  },
]);
