import { Clock, CheckCircle2, AlertCircle, BookOpen } from "lucide-react";

const SCHEDULE: { day: string; classes: { time: string; subject: string; teacher: string; color: string }[] }[] = [
  {
    day: "Mon",
    classes: [
      { time: "07:00", subject: "Mathematics", teacher: "Mr. Ramírez", color: "#dbeafe" },
      { time: "09:00", subject: "Physics", teacher: "Ms. Torres", color: "#fef9c3" },
    ],
  },
  {
    day: "Tue",
    classes: [
      { time: "07:00", subject: "Literature", teacher: "Ms. García", color: "#dcfce7" },
      { time: "10:00", subject: "History", teacher: "Mr. Flores", color: "#fce7f3" },
    ],
  },
  {
    day: "Wed",
    classes: [
      { time: "08:00", subject: "Chemistry", teacher: "Dr. Méndez", color: "#ede9fe" },
      { time: "11:00", subject: "Mathematics", teacher: "Mr. Ramírez", color: "#dbeafe" },
    ],
  },
  {
    day: "Thu",
    classes: [
      { time: "07:00", subject: "English", teacher: "Ms. Collins", color: "#ffedd5" },
      { time: "09:00", subject: "Biology", teacher: "Dr. Ruiz", color: "#dcfce7" },
    ],
  },
  {
    day: "Fri",
    classes: [
      { time: "08:00", subject: "Physics", teacher: "Ms. Torres", color: "#fef9c3" },
      { time: "10:00", subject: "Art", teacher: "Mr. Vega", color: "#fce7f3" },
    ],
  },
];

const PENDING_EVALS = [
  { id: 1, subject: "Mathematics", type: "Mid-term Exam", dueDate: "Jul 5, 2026", weight: "30%", status: "upcoming", dot: "#1a56db" },
  { id: 2, subject: "Chemistry", type: "Lab Report", dueDate: "Jul 7, 2026", weight: "15%", status: "upcoming", dot: "#7c3aed" },
  { id: 3, subject: "Literature", type: "Essay Submission", dueDate: "Jul 10, 2026", weight: "20%", status: "upcoming", dot: "#16a34a" },
  { id: 4, subject: "History", type: "Oral Presentation", dueDate: "Jul 12, 2026", weight: "25%", status: "late", dot: "#dc2626" },
];

export function DashboardPage() {
  const today = new Date();
  const dayIndex = today.getDay();
  const weekdays = ["Mon", "Tue", "Wed", "Thu", "Fri"];
  const activeDay = dayIndex >= 1 && dayIndex <= 5 ? weekdays[dayIndex - 1] : "Mon";

  return (
    <>
      {/* Summary Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px" }}>
        {/* Solvency Status */}
        <div style={{ backgroundColor: "#ffffff", borderRadius: "14px", padding: "20px", border: "1px solid #f3f4f6", display: "flex", flexDirection: "column", gap: "10px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <p style={{ color: "#6b7280", fontSize: "0.75rem", fontWeight: 500, margin: 0, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                Solvency Status
              </p>
              <p style={{ color: "#111827", fontSize: "1.4rem", fontWeight: 700, margin: "4px 0 0" }}>Solvent</p>
            </div>
            <div style={{ width: "40px", height: "40px", borderRadius: "10px", backgroundColor: "#dcfce7", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <CheckCircle2 style={{ width: "20px", height: "20px", color: "#16a34a" }} />
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
            <div style={{ height: "6px", flex: 1, backgroundColor: "#f3f4f6", borderRadius: "99px", overflow: "hidden" }}>
              <div style={{ height: "100%", width: "100%", backgroundColor: "#16a34a", borderRadius: "99px" }} />
            </div>
            <span style={{ fontSize: "0.7rem", color: "#16a34a", fontWeight: 600 }}>Paid</span>
          </div>
          <p style={{ color: "#9ca3af", fontSize: "0.75rem", margin: 0 }}>Next payment: Aug 1, 2026</p>
        </div>

        {/* Next Class */}
        <div style={{ backgroundColor: "#ffffff", borderRadius: "14px", padding: "20px", border: "1px solid #f3f4f6", display: "flex", flexDirection: "column", gap: "10px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <p style={{ color: "#6b7280", fontSize: "0.75rem", fontWeight: 500, margin: 0, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                Next Class
              </p>
              <p style={{ color: "#111827", fontSize: "1.1rem", fontWeight: 700, margin: "4px 0 0" }}>Mathematics</p>
            </div>
            <div style={{ width: "40px", height: "40px", borderRadius: "10px", backgroundColor: "#dbeafe", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Clock style={{ width: "20px", height: "20px", color: "#1a56db" }} />
            </div>
          </div>
          <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
            <span style={{ backgroundColor: "#eff6ff", color: "#1a56db", fontSize: "0.7rem", fontWeight: 600, padding: "3px 8px", borderRadius: "6px" }}>
              Today · 11:00 AM
            </span>
            <span style={{ backgroundColor: "#f9fafb", color: "#6b7280", fontSize: "0.7rem", fontWeight: 500, padding: "3px 8px", borderRadius: "6px" }}>
              Room 204
            </span>
          </div>
          <p style={{ color: "#9ca3af", fontSize: "0.75rem", margin: 0 }}>Mr. Ramírez · Starts in 1h 20m</p>
        </div>

        {/* Overall Attendance */}
        <div style={{ backgroundColor: "#ffffff", borderRadius: "14px", padding: "20px", border: "1px solid #f3f4f6", display: "flex", flexDirection: "column", gap: "10px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <p style={{ color: "#6b7280", fontSize: "0.75rem", fontWeight: 500, margin: 0, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                Overall Attendance
              </p>
              <p style={{ color: "#111827", fontSize: "1.4rem", fontWeight: 700, margin: "4px 0 0" }}>92.4%</p>
            </div>
            <div style={{ width: "40px", height: "40px", borderRadius: "10px", backgroundColor: "#fef9c3", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <AlertCircle style={{ width: "20px", height: "20px", color: "#ca8a04" }} />
            </div>
          </div>
          <div style={{ display: "flex", gap: "4px" }}>
            {Array.from({ length: 20 }).map((_, i) => (
              <div key={i} style={{ flex: 1, height: "6px", borderRadius: "99px", backgroundColor: i < 18 ? "#1a56db" : "#fee2e2" }} />
            ))}
          </div>
          <p style={{ color: "#9ca3af", fontSize: "0.75rem", margin: 0 }}>2 absences this term · Min. required: 75%</p>
        </div>
      </div>

      {/* Weekly Schedule */}
      <div style={{ backgroundColor: "#ffffff", borderRadius: "14px", border: "1px solid #f3f4f6", overflow: "hidden" }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid #f3f4f6", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h3 style={{ margin: 0, color: "#111827", fontWeight: 600, fontSize: "0.9375rem" }}>Weekly Schedule</h3>
          <span style={{ fontSize: "0.8rem", color: "#1a56db", cursor: "pointer", fontWeight: 500 }}>View full schedule →</span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)" }}>
          {SCHEDULE.map(({ day, classes }) => {
            const isToday = day === activeDay;
            return (
              <div key={day} style={{ padding: "14px 12px", borderRight: day !== "Fri" ? "1px solid #f3f4f6" : "none" }}>
                <div style={{ fontSize: "0.75rem", fontWeight: 700, color: isToday ? "#1a56db" : "#9ca3af", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "10px", display: "flex", alignItems: "center", gap: "5px" }}>
                  {day}
                  {isToday && <span style={{ width: "6px", height: "6px", borderRadius: "50%", backgroundColor: "#1a56db", display: "inline-block" }} />}
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  {classes.map((cls, i) => (
                    <div key={i} style={{ backgroundColor: cls.color, borderRadius: "8px", padding: "8px 10px" }}>
                      <div style={{ fontSize: "0.7rem", color: "#6b7280", fontWeight: 500 }}>{cls.time}</div>
                      <div style={{ fontSize: "0.8rem", color: "#111827", fontWeight: 600, marginTop: "1px" }}>{cls.subject}</div>
                      <div style={{ fontSize: "0.7rem", color: "#6b7280", marginTop: "1px" }}>{cls.teacher}</div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Pending Evaluations */}
      <div style={{ backgroundColor: "#ffffff", borderRadius: "14px", border: "1px solid #f3f4f6", overflow: "hidden" }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid #f3f4f6", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h3 style={{ margin: 0, color: "#111827", fontWeight: 600, fontSize: "0.9375rem" }}>Pending Evaluations</h3>
          <span style={{ fontSize: "0.8rem", color: "#1a56db", cursor: "pointer", fontWeight: 500 }}>View all →</span>
        </div>
        <div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr 1fr 0.5fr 0.8fr", padding: "10px 20px", backgroundColor: "#f9fafb", borderBottom: "1px solid #f3f4f6" }}>
            {["Subject", "Evaluation", "Due Date", "Weight", "Status"].map((h) => (
              <span key={h} style={{ fontSize: "0.7rem", fontWeight: 600, color: "#9ca3af", textTransform: "uppercase", letterSpacing: "0.05em" }}>{h}</span>
            ))}
          </div>
          {PENDING_EVALS.map((ev, i) => (
            <div
              key={ev.id}
              style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr 1fr 0.5fr 0.8fr", padding: "13px 20px", borderBottom: i < PENDING_EVALS.length - 1 ? "1px solid #f9fafb" : "none", alignItems: "center", cursor: "pointer", transition: "background-color 0.12s" }}
              onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#f9fafb")}
              onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <span style={{ width: "8px", height: "8px", borderRadius: "50%", backgroundColor: ev.dot, flexShrink: 0 }} />
                <span style={{ fontSize: "0.875rem", color: "#111827", fontWeight: 500 }}>{ev.subject}</span>
              </div>
              <span style={{ fontSize: "0.875rem", color: "#374151" }}>{ev.type}</span>
              <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                <Clock style={{ width: "12px", height: "12px", color: "#9ca3af", flexShrink: 0 }} />
                <span style={{ fontSize: "0.8125rem", color: "#6b7280" }}>{ev.dueDate}</span>
              </div>
              <span style={{ fontSize: "0.875rem", color: "#374151", fontWeight: 600 }}>{ev.weight}</span>
              <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", padding: "3px 10px", borderRadius: "99px", fontSize: "0.7rem", fontWeight: 600, backgroundColor: ev.status === "late" ? "#fee2e2" : "#fef9c3", color: ev.status === "late" ? "#dc2626" : "#b45309", width: "fit-content" }}>
                {ev.status === "late" ? "Overdue" : "Upcoming"}
              </span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
