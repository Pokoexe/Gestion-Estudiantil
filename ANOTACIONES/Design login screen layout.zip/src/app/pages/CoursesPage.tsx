import { useState } from "react";
import {
  Phone,
  Mail,
  ChevronDown,
  ChevronUp,
  Download,
  FileText,
  Clock,
  CheckCircle2,
  Circle,
  BookOpen,
  ListChecks,
  Presentation,
  FlaskConical,
  PenLine,
} from "lucide-react";

interface Topic {
  id: number;
  text: string;
}

interface Assignment {
  id: number;
  title: string;
  type: "presentation" | "exam" | "lab" | "essay";
  dueDate: string;
  weight: string;
  status: "pending" | "submitted" | "graded";
  grade?: string;
  description?: string;
  duration?: string;
  topics?: Topic[];
  hasAttachment?: boolean;
  attachmentName?: string;
}

const COURSE = {
  name: "Natural Sciences",
  code: "NSC-401",
  section: "Section B",
  room: "Lab 102",
  schedule: "Mon / Wed · 07:00 – 08:30",
  term: "2026-I",
};

const TEACHER = {
  name: "Prof. Alejandro Morales",
  title: "Senior Sciences Teacher",
  phone: "+58 412-555-0193",
  email: "a.morales@edumanage.edu",
  initials: "AM",
};

const ASSIGNMENTS: Assignment[] = [
  {
    id: 1,
    title: "Petroleum Presentation",
    type: "presentation",
    dueDate: "Jul 10, 2026",
    weight: "20%",
    status: "pending",
    description:
      "Prepare and deliver an oral presentation about petroleum as a natural resource. Your presentation must be clear, well-structured, and visually supported.",
    duration: "5 minutes",
    topics: [
      { id: 1, text: "What is petroleum? (origin, composition, types)" },
      { id: 2, text: "Where is it found? (major reserves, extraction regions)" },
      { id: 3, text: "Why is it important? (economic, energetic, and social relevance)" },
    ],
    hasAttachment: true,
    attachmentName: "Petroleum_Presentation_Guide.pdf",
  },
  {
    id: 2,
    title: "Unit 3 Written Exam",
    type: "exam",
    dueDate: "Jul 17, 2026",
    weight: "30%",
    status: "pending",
    description: "Closed-book written exam covering all topics from Unit 3: Earth's Resources.",
    duration: "90 minutes",
    hasAttachment: false,
  },
  {
    id: 3,
    title: "Water Cycle Lab Report",
    type: "lab",
    dueDate: "Jun 28, 2026",
    weight: "15%",
    status: "graded",
    grade: "88",
    description: "Lab report documenting the water cycle experiment conducted in Week 6.",
    hasAttachment: false,
  },
  {
    id: 4,
    title: "Renewable Energy Essay",
    type: "essay",
    dueDate: "Jul 24, 2026",
    weight: "20%",
    status: "pending",
    description: "Write a 600–800 word essay comparing two renewable energy sources.",
    hasAttachment: true,
    attachmentName: "Essay_Rubric.pdf",
  },
  {
    id: 5,
    title: "Biodiversity Quiz",
    type: "exam",
    dueDate: "Jun 20, 2026",
    weight: "15%",
    status: "graded",
    grade: "95",
    hasAttachment: false,
  },
];

const TYPE_META: Record<Assignment["type"], { icon: React.FC<{ style?: React.CSSProperties }>, bg: string, color: string, label: string }> = {
  presentation: { icon: Presentation, bg: "#eff6ff", color: "#1a56db", label: "Presentation" },
  exam: { icon: FileText, bg: "#fef9c3", color: "#b45309", label: "Exam" },
  lab: { icon: FlaskConical, bg: "#dcfce7", color: "#16a34a", label: "Lab Report" },
  essay: { icon: PenLine, bg: "#ede9fe", color: "#7c3aed", label: "Essay" },
};

const STATUS_META: Record<Assignment["status"], { bg: string; color: string; label: string }> = {
  pending: { bg: "#fef9c3", color: "#b45309", label: "Pending" },
  submitted: { bg: "#dbeafe", color: "#1a56db", label: "Submitted" },
  graded: { bg: "#dcfce7", color: "#16a34a", label: "Graded" },
};

function AssignmentCard({ assignment }: { assignment: Assignment }) {
  const [expanded, setExpanded] = useState(assignment.id === 1);
  const typeMeta = TYPE_META[assignment.type];
  const statusMeta = STATUS_META[assignment.status];
  const TypeIcon = typeMeta.icon;

  return (
    <div
      style={{
        backgroundColor: "#ffffff",
        borderRadius: "12px",
        border: expanded ? "1.5px solid #bfdbfe" : "1px solid #f3f4f6",
        overflow: "hidden",
        transition: "border-color 0.15s",
      }}
    >
      {/* Card header row */}
      <button
        onClick={() => setExpanded(!expanded)}
        style={{
          width: "100%",
          display: "flex",
          alignItems: "center",
          gap: "14px",
          padding: "16px 18px",
          background: "none",
          border: "none",
          cursor: "pointer",
          textAlign: "left",
        }}
      >
        {/* Type icon */}
        <div
          style={{
            width: "40px",
            height: "40px",
            borderRadius: "10px",
            backgroundColor: typeMeta.bg,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
          }}
        >
          <TypeIcon style={{ width: "18px", height: "18px", color: typeMeta.color }} />
        </div>

        {/* Info */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" }}>
            <span style={{ fontSize: "0.9rem", fontWeight: 600, color: "#111827" }}>{assignment.title}</span>
            <span
              style={{
                fontSize: "0.68rem",
                fontWeight: 600,
                padding: "2px 8px",
                borderRadius: "99px",
                backgroundColor: typeMeta.bg,
                color: typeMeta.color,
              }}
            >
              {typeMeta.label}
            </span>
          </div>
          <div style={{ display: "flex", gap: "12px", marginTop: "4px", flexWrap: "wrap" }}>
            <span style={{ fontSize: "0.775rem", color: "#6b7280", display: "flex", alignItems: "center", gap: "4px" }}>
              <Clock style={{ width: "11px", height: "11px" }} />
              {assignment.dueDate}
            </span>
            <span style={{ fontSize: "0.775rem", color: "#6b7280" }}>Weight: <strong style={{ color: "#374151" }}>{assignment.weight}</strong></span>
            {assignment.status === "graded" && (
              <span style={{ fontSize: "0.775rem", color: "#16a34a", fontWeight: 600 }}>
                Grade: {assignment.grade}/100
              </span>
            )}
          </div>
        </div>

        {/* Status badge */}
        <span
          style={{
            fontSize: "0.7rem",
            fontWeight: 600,
            padding: "3px 10px",
            borderRadius: "99px",
            backgroundColor: statusMeta.bg,
            color: statusMeta.color,
            flexShrink: 0,
          }}
        >
          {statusMeta.label}
        </span>

        {/* Chevron */}
        <div style={{ color: "#9ca3af", flexShrink: 0 }}>
          {expanded ? <ChevronUp style={{ width: "16px", height: "16px" }} /> : <ChevronDown style={{ width: "16px", height: "16px" }} />}
        </div>
      </button>

      {/* Expanded detail */}
      {expanded && (
        <div
          style={{
            borderTop: "1px solid #f3f4f6",
            padding: "20px 18px",
            backgroundColor: "#fafbff",
            display: "flex",
            flexDirection: "column",
            gap: "16px",
          }}
        >
          {/* Description */}
          {assignment.description && (
            <div>
              <p style={{ fontSize: "0.78rem", fontWeight: 600, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.05em", margin: "0 0 6px" }}>
                Instructions
              </p>
              <p style={{ fontSize: "0.875rem", color: "#374151", lineHeight: 1.65, margin: 0 }}>
                {assignment.description}
              </p>
            </div>
          )}

          {/* Duration */}
          {assignment.duration && (
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <div style={{ width: "32px", height: "32px", borderRadius: "8px", backgroundColor: "#f3f4f6", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Clock style={{ width: "15px", height: "15px", color: "#6b7280" }} />
              </div>
              <div>
                <div style={{ fontSize: "0.7rem", color: "#9ca3af", fontWeight: 500 }}>Required duration</div>
                <div style={{ fontSize: "0.875rem", color: "#111827", fontWeight: 600 }}>{assignment.duration}</div>
              </div>
            </div>
          )}

          {/* Topics */}
          {assignment.topics && assignment.topics.length > 0 && (
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "10px" }}>
                <ListChecks style={{ width: "15px", height: "15px", color: "#1a56db" }} />
                <p style={{ fontSize: "0.78rem", fontWeight: 600, color: "#374151", margin: 0 }}>
                  Required Topics ({assignment.topics.length})
                </p>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                {assignment.topics.map((topic) => (
                  <div
                    key={topic.id}
                    style={{
                      display: "flex",
                      alignItems: "flex-start",
                      gap: "10px",
                      padding: "10px 14px",
                      backgroundColor: "#eff6ff",
                      borderRadius: "8px",
                      border: "1px solid #dbeafe",
                    }}
                  >
                    <div
                      style={{
                        width: "22px",
                        height: "22px",
                        borderRadius: "50%",
                        backgroundColor: "#1a56db",
                        color: "#fff",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: "0.7rem",
                        fontWeight: 700,
                        flexShrink: 0,
                        marginTop: "1px",
                      }}
                    >
                      {topic.id}
                    </div>
                    <span style={{ fontSize: "0.875rem", color: "#1e3a5f", lineHeight: 1.5 }}>{topic.text}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Download button */}
          {assignment.hasAttachment && (
            <div style={{ paddingTop: "4px" }}>
              <button
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "8px",
                  padding: "9px 18px",
                  borderRadius: "9px",
                  border: "1.5px solid #bfdbfe",
                  backgroundColor: "#eff6ff",
                  color: "#1a56db",
                  fontSize: "0.875rem",
                  fontWeight: 600,
                  cursor: "pointer",
                  transition: "background-color 0.15s",
                }}
                onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#dbeafe")}
                onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "#eff6ff")}
              >
                <Download style={{ width: "15px", height: "15px" }} />
                Download Attached Test
                {assignment.attachmentName && (
                  <span style={{ fontSize: "0.75rem", color: "#6b7280", fontWeight: 400 }}>
                    · {assignment.attachmentName}
                  </span>
                )}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export function CoursesPage() {
  const pendingCount = ASSIGNMENTS.filter((a) => a.status === "pending").length;
  const gradedCount = ASSIGNMENTS.filter((a) => a.status === "graded").length;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
      {/* Course header banner */}
      <div
        style={{
          backgroundColor: "#1a56db",
          borderRadius: "14px",
          padding: "22px 24px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: "12px",
        }}
      >
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
            <BookOpen style={{ width: "16px", height: "16px", color: "rgba(255,255,255,0.8)" }} />
            <span style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.75)", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.06em" }}>
              {COURSE.code} · {COURSE.section}
            </span>
          </div>
          <h2 style={{ color: "#ffffff", margin: "0 0 6px", fontSize: "1.25rem", fontWeight: 700 }}>{COURSE.name}</h2>
          <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
            {[COURSE.schedule, COURSE.room, `Term ${COURSE.term}`].map((item) => (
              <span key={item} style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.75)" }}>{item}</span>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", gap: "12px" }}>
          {[
            { label: "Pending", value: pendingCount, bg: "rgba(255,255,255,0.15)", color: "#fff" },
            { label: "Graded", value: gradedCount, bg: "rgba(255,255,255,0.15)", color: "#fff" },
          ].map(({ label, value, bg, color }) => (
            <div key={label} style={{ backgroundColor: bg, borderRadius: "10px", padding: "10px 18px", textAlign: "center" }}>
              <div style={{ fontSize: "1.3rem", fontWeight: 700, color }}>{value}</div>
              <div style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.75)", marginTop: "1px" }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Teacher info card */}
      <div
        style={{
          backgroundColor: "#ffffff",
          borderRadius: "14px",
          border: "1px solid #f3f4f6",
          padding: "18px 22px",
          display: "flex",
          alignItems: "center",
          gap: "16px",
          flexWrap: "wrap",
        }}
      >
        {/* Avatar */}
        <div
          style={{
            width: "52px",
            height: "52px",
            borderRadius: "50%",
            backgroundColor: "#eff6ff",
            border: "2px solid #dbeafe",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "1rem",
            fontWeight: 700,
            color: "#1a56db",
            flexShrink: 0,
          }}
        >
          {TEACHER.initials}
        </div>

        {/* Name & title */}
        <div style={{ flex: 1, minWidth: "160px" }}>
          <div style={{ fontSize: "0.9375rem", fontWeight: 700, color: "#111827" }}>{TEACHER.name}</div>
          <div style={{ fontSize: "0.8rem", color: "#6b7280", marginTop: "2px" }}>{TEACHER.title}</div>
        </div>

        {/* Divider */}
        <div style={{ width: "1px", height: "40px", backgroundColor: "#f3f4f6", flexShrink: 0 }} />

        {/* Contact details */}
        <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
          <a
            href={`tel:${TEACHER.phone}`}
            style={{ display: "flex", alignItems: "center", gap: "8px", color: "#374151", textDecoration: "none", fontSize: "0.875rem" }}
          >
            <div style={{ width: "28px", height: "28px", borderRadius: "7px", backgroundColor: "#dcfce7", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Phone style={{ width: "13px", height: "13px", color: "#16a34a" }} />
            </div>
            <span style={{ fontWeight: 500 }}>{TEACHER.phone}</span>
          </a>
          <a
            href={`mailto:${TEACHER.email}`}
            style={{ display: "flex", alignItems: "center", gap: "8px", color: "#374151", textDecoration: "none", fontSize: "0.875rem" }}
          >
            <div style={{ width: "28px", height: "28px", borderRadius: "7px", backgroundColor: "#eff6ff", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Mail style={{ width: "13px", height: "13px", color: "#1a56db" }} />
            </div>
            <span style={{ fontWeight: 500 }}>{TEACHER.email}</span>
          </a>
        </div>
      </div>

      {/* Evaluation Plan */}
      <div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
          <div>
            <h3 style={{ margin: 0, color: "#111827", fontWeight: 700, fontSize: "1rem" }}>Evaluation Plan</h3>
            <p style={{ margin: "2px 0 0", color: "#9ca3af", fontSize: "0.8rem" }}>
              {ASSIGNMENTS.length} evaluations · Total weight: 100%
            </p>
          </div>
          <div style={{ display: "flex", gap: "6px" }}>
            {(["All", "Pending", "Graded"] as const).map((f) => (
              <button
                key={f}
                style={{
                  padding: "5px 12px",
                  borderRadius: "7px",
                  border: "1.5px solid",
                  fontSize: "0.775rem",
                  fontWeight: 500,
                  cursor: "pointer",
                  borderColor: f === "All" ? "#1a56db" : "#e5e7eb",
                  backgroundColor: f === "All" ? "#eff6ff" : "transparent",
                  color: f === "All" ? "#1a56db" : "#6b7280",
                }}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
          {ASSIGNMENTS.map((assignment) => (
            <AssignmentCard key={assignment.id} assignment={assignment} />
          ))}
        </div>
      </div>

      {/* Grade summary */}
      <div
        style={{
          backgroundColor: "#ffffff",
          borderRadius: "14px",
          border: "1px solid #f3f4f6",
          padding: "16px 22px",
          display: "flex",
          gap: "0",
        }}
      >
        {[
          { label: "Completed", value: `${gradedCount}/${ASSIGNMENTS.length}`, color: "#16a34a", bg: "#dcfce7" },
          { label: "Weighted Average", value: "91.5", color: "#1a56db", bg: "#eff6ff" },
          { label: "Remaining Weight", value: "65%", color: "#b45309", bg: "#fef9c3" },
          { label: "Projected Final", value: "On track", color: "#7c3aed", bg: "#ede9fe" },
        ].map(({ label, value, color, bg }, i, arr) => (
          <div
            key={label}
            style={{
              flex: 1,
              padding: "10px 16px",
              borderRight: i < arr.length - 1 ? "1px solid #f3f4f6" : "none",
              display: "flex",
              flexDirection: "column",
              gap: "4px",
            }}
          >
            <div style={{ fontSize: "0.72rem", color: "#9ca3af", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.05em" }}>{label}</div>
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "6px",
              }}
            >
              <span
                style={{
                  width: "8px",
                  height: "8px",
                  borderRadius: "50%",
                  backgroundColor: color,
                  display: "inline-block",
                  flexShrink: 0,
                }}
              />
              <span style={{ fontSize: "1rem", fontWeight: 700, color: "#111827" }}>{value}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
