import { useState } from "react";
import { useNavigate } from "react-router";
import { Eye, EyeOff, GraduationCap, MessageCircle } from "lucide-react";

export function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      navigate("/dashboard");
    }, 1200);
  };

  return (
    <div className="min-h-screen w-full flex">
      {/* Left Panel — Login Form */}
      <div className="flex flex-1 flex-col justify-center items-center px-8 py-12 bg-white lg:max-w-[520px] w-full">
        <div className="w-full max-w-[380px]">
          {/* Logo */}
          <div className="flex items-center gap-2.5 mb-10">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ backgroundColor: "#1a56db" }}
            >
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <span
              className="tracking-tight"
              style={{ color: "#111827", fontSize: "1.1rem", fontWeight: 600 }}
            >
              EduManage
            </span>
          </div>

          {/* Heading */}
          <div className="mb-8">
            <h1
              className="mb-1"
              style={{ color: "#111827", fontWeight: 700, fontSize: "1.6rem", lineHeight: 1.3 }}
            >
              Welcome back
            </h1>
            <p style={{ color: "#6b7280", fontSize: "0.95rem" }}>
              Sign in to your school management account
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            {/* Email */}
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="email"
                style={{ color: "#374151", fontSize: "0.875rem", fontWeight: 500 }}
              >
                Email address
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                placeholder="you@school.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                style={{
                  border: "1.5px solid #e5e7eb",
                  borderRadius: "10px",
                  padding: "10px 14px",
                  color: "#111827",
                  outline: "none",
                  transition: "border-color 0.15s",
                  backgroundColor: "#f9fafb",
                  fontSize: "0.9375rem",
                  width: "100%",
                  boxSizing: "border-box",
                }}
                onFocus={(e) => (e.target.style.borderColor = "#1a56db")}
                onBlur={(e) => (e.target.style.borderColor = "#e5e7eb")}
              />
            </div>

            {/* Password */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <label
                  htmlFor="password"
                  style={{ color: "#374151", fontSize: "0.875rem", fontWeight: 500 }}
                >
                  Password
                </label>
                <a
                  href="#"
                  style={{ color: "#1a56db", fontSize: "0.8125rem", fontWeight: 500, textDecoration: "none" }}
                  onMouseOver={(e) => ((e.target as HTMLElement).style.textDecoration = "underline")}
                  onMouseOut={(e) => ((e.target as HTMLElement).style.textDecoration = "none")}
                >
                  Forgot password?
                </a>
              </div>
              <div style={{ position: "relative" }}>
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  style={{
                    border: "1.5px solid #e5e7eb",
                    borderRadius: "10px",
                    padding: "10px 44px 10px 14px",
                    color: "#111827",
                    outline: "none",
                    transition: "border-color 0.15s",
                    backgroundColor: "#f9fafb",
                    fontSize: "0.9375rem",
                    width: "100%",
                    boxSizing: "border-box",
                  }}
                  onFocus={(e) => (e.target.style.borderColor = "#1a56db")}
                  onBlur={(e) => (e.target.style.borderColor = "#e5e7eb")}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{
                    position: "absolute",
                    right: "12px",
                    top: "50%",
                    transform: "translateY(-50%)",
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                    color: "#9ca3af",
                    padding: 0,
                    display: "flex",
                    alignItems: "center",
                  }}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              style={{
                backgroundColor: loading ? "#3b6fd4" : "#1a56db",
                color: "#ffffff",
                border: "none",
                borderRadius: "10px",
                padding: "11px 0",
                cursor: loading ? "not-allowed" : "pointer",
                transition: "background-color 0.15s",
                marginTop: "2px",
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
                fontSize: "0.9375rem",
                fontWeight: 600,
              }}
              onMouseOver={(e) => { if (!loading) (e.currentTarget.style.backgroundColor = "#1447c0"); }}
              onMouseOut={(e) => { if (!loading) (e.currentTarget.style.backgroundColor = "#1a56db"); }}
            >
              {loading ? (
                <>
                  <svg className="animate-spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                  </svg>
                  Signing in…
                </>
              ) : (
                "Log In"
              )}
            </button>
          </form>

          {/* WhatsApp Support */}
          <div className="mt-6 flex items-center justify-center gap-2">
            <MessageCircle className="w-4 h-4 flex-shrink-0" style={{ color: "#25d366" }} />
            <span style={{ color: "#6b7280", fontSize: "0.8125rem" }}>
              Need help?{" "}
              <a
                href="https://wa.me/"
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: "#25d366", fontWeight: 600, textDecoration: "none" }}
                onMouseOver={(e) => ((e.target as HTMLElement).style.textDecoration = "underline")}
                onMouseOut={(e) => ((e.target as HTMLElement).style.textDecoration = "none")}
              >
                Contact WhatsApp Support
              </a>
            </span>
          </div>
        </div>

        <p style={{ color: "#d1d5db", fontSize: "0.75rem", marginTop: "auto", paddingTop: "32px" }}>
          © 2026 EduManage. All rights reserved.
        </p>
      </div>

      {/* Right Panel — School Photo */}
      <div className="hidden lg:flex flex-1 relative overflow-hidden" style={{ minHeight: "100vh" }}>
        <img
          src="https://images.unsplash.com/photo-1778751225720-ee0f1d2ad14e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHxtb2Rlcm4lMjBzY2hvb2wlMjJidWlsZGluZyUyMGVkdWNhdGlvbiUyMGNhbXB1c3xlbnwxfHx8fDE3ODI5NTYxNTJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Modern school campus"
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "center" }}
        />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg, rgba(26,86,219,0.72) 0%, rgba(17,24,39,0.55) 100%)" }} />
        <div style={{ position: "relative", zIndex: 10, display: "flex", flexDirection: "column", justifyContent: "flex-end", padding: "48px 52px", height: "100%" }}>
          <div style={{ backgroundColor: "rgba(255,255,255,0.1)", backdropFilter: "blur(12px)", borderRadius: "16px", border: "1px solid rgba(255,255,255,0.18)", padding: "28px 32px", maxWidth: "420px" }}>
            <div className="flex items-center gap-3 mb-3">
              <div style={{ width: "36px", height: "36px", borderRadius: "50%", backgroundColor: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <span style={{ color: "rgba(255,255,255,0.9)", fontSize: "0.8rem", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase" }}>
                School Management
              </span>
            </div>
            <p style={{ color: "#ffffff", fontSize: "1.25rem", fontWeight: 600, lineHeight: 1.4, marginBottom: "10px" }}>
              Everything your institution needs, in one place.
            </p>
            <p style={{ color: "rgba(255,255,255,0.72)", fontSize: "0.875rem", lineHeight: 1.6 }}>
              Manage students, staff, grades, attendance, and communications — all from a single, unified dashboard.
            </p>
            <div className="flex items-center gap-5 mt-5">
              {[["500+", "Schools"], ["98%", "Satisfaction"], ["24/7", "Support"]].map(([stat, label]) => (
                <div key={label}>
                  <div style={{ color: "#ffffff", fontWeight: 700, fontSize: "1.1rem" }}>{stat}</div>
                  <div style={{ color: "rgba(255,255,255,0.6)", fontSize: "0.75rem" }}>{label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
