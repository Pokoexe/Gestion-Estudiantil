import { useState } from "react";
import { Outlet, useNavigate, useLocation } from "react-router";
import {
  Home,
  Calendar,
  BarChart2,
  Star,
  CreditCard,
  Bell,
  ChevronDown,
  GraduationCap,
  BookOpen,
  LogOut,
  User,
  Layers,
} from "lucide-react";

const NAV_ITEMS = [
  { icon: Home, label: "Home", path: "/dashboard" },
  { icon: Layers, label: "Courses", path: "/dashboard/courses" },
  { icon: Calendar, label: "Schedule", path: "/dashboard/schedule" },
  { icon: BarChart2, label: "Grades", path: "/dashboard/grades" },
  { icon: Star, label: "Extracurriculars", path: "/dashboard/extracurriculars" },
  { icon: CreditCard, label: "Payments", path: "/dashboard/payments" },
];

const TERMS = ["2026-I", "2026-II", "2025-II", "2025-I"];

export function AppLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [term, setTerm] = useState("2026-I");
  const [showTermDropdown, setShowTermDropdown] = useState(false);
  const [notifications] = useState(3);
  const [showNotifications, setShowNotifications] = useState(false);

  const today = new Date();

  // Determine active nav: exact match for /dashboard, prefix match for children
  const getIsActive = (path: string) => {
    if (path === "/dashboard") return location.pathname === "/dashboard";
    return location.pathname.startsWith(path);
  };

  const pageTitle: Record<string, string> = {
    "/dashboard": "Student Dashboard",
    "/dashboard/courses": "My Courses",
    "/dashboard/schedule": "Schedule",
    "/dashboard/grades": "Grades",
    "/dashboard/extracurriculars": "Extracurriculars",
    "/dashboard/payments": "Payments",
  };

  const currentTitle =
    Object.entries(pageTitle).find(([path]) =>
      path === "/dashboard"
        ? location.pathname === "/dashboard"
        : location.pathname.startsWith(path)
    )?.[1] ?? "Dashboard";

  return (
    <div className="flex min-h-screen" style={{ backgroundColor: "#f3f4f6" }}>
      {/* Sidebar */}
      <aside
        style={{
          width: "220px",
          minHeight: "100vh",
          backgroundColor: "#ffffff",
          borderRight: "1px solid #e5e7eb",
          display: "flex",
          flexDirection: "column",
          flexShrink: 0,
        }}
      >
        {/* Logo */}
        <div
          style={{
            padding: "20px 20px 16px",
            borderBottom: "1px solid #f3f4f6",
            display: "flex",
            alignItems: "center",
            gap: "10px",
          }}
        >
          <div
            style={{
              width: "34px",
              height: "34px",
              borderRadius: "10px",
              backgroundColor: "#1a56db",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <GraduationCap className="w-4 h-4 text-white" />
          </div>
          <span style={{ color: "#111827", fontWeight: 600, fontSize: "0.95rem" }}>EduManage</span>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: "12px 10px", display: "flex", flexDirection: "column", gap: "2px" }}>
          {NAV_ITEMS.map(({ icon: Icon, label, path }) => {
            const isActive = getIsActive(path);
            return (
              <button
                key={label}
                onClick={() => navigate(path)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "9px 12px",
                  borderRadius: "8px",
                  border: "none",
                  cursor: "pointer",
                  backgroundColor: isActive ? "#eff6ff" : "transparent",
                  color: isActive ? "#1a56db" : "#6b7280",
                  fontWeight: isActive ? 600 : 400,
                  fontSize: "0.875rem",
                  width: "100%",
                  textAlign: "left",
                  transition: "background-color 0.15s, color 0.15s",
                }}
                onMouseOver={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.backgroundColor = "#f9fafb";
                    e.currentTarget.style.color = "#374151";
                  }
                }}
                onMouseOut={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.backgroundColor = "transparent";
                    e.currentTarget.style.color = "#6b7280";
                  }
                }}
              >
                <Icon style={{ width: "17px", height: "17px", flexShrink: 0 }} />
                <span>{label}</span>
              </button>
            );
          })}
        </nav>

        {/* User */}
        <div
          style={{
            padding: "12px 10px",
            borderTop: "1px solid #f3f4f6",
            display: "flex",
            alignItems: "center",
            gap: "10px",
          }}
        >
          <div
            style={{
              width: "32px",
              height: "32px",
              borderRadius: "50%",
              backgroundColor: "#dbeafe",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <User style={{ width: "15px", height: "15px", color: "#1a56db" }} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ color: "#111827", fontSize: "0.8rem", fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              Carlos Mendoza
            </div>
            <div style={{ color: "#9ca3af", fontSize: "0.7rem" }}>Student</div>
          </div>
          <button
            onClick={() => navigate("/")}
            style={{ background: "none", border: "none", cursor: "pointer", color: "#9ca3af", padding: "2px", display: "flex" }}
            title="Log out"
          >
            <LogOut style={{ width: "15px", height: "15px" }} />
          </button>
        </div>
      </aside>

      {/* Main column */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        {/* Header */}
        <header
          style={{
            height: "60px",
            backgroundColor: "#ffffff",
            borderBottom: "1px solid #e5e7eb",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0 24px",
            gap: "16px",
            position: "sticky",
            top: 0,
            zIndex: 20,
          }}
        >
          <div>
            <h2 style={{ color: "#111827", fontWeight: 600, fontSize: "1rem", margin: 0 }}>{currentTitle}</h2>
            <p style={{ color: "#9ca3af", fontSize: "0.75rem", margin: 0 }}>
              {today.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
            </p>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            {/* Term selector */}
            <div style={{ position: "relative" }}>
              <button
                onClick={() => { setShowTermDropdown(!showTermDropdown); setShowNotifications(false); }}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  padding: "6px 12px",
                  borderRadius: "8px",
                  border: "1.5px solid #e5e7eb",
                  backgroundColor: "#f9fafb",
                  color: "#374151",
                  fontSize: "0.8125rem",
                  fontWeight: 500,
                  cursor: "pointer",
                }}
              >
                <BookOpen style={{ width: "14px", height: "14px", color: "#1a56db" }} />
                Term {term}
                <ChevronDown style={{ width: "13px", height: "13px", color: "#9ca3af" }} />
              </button>
              {showTermDropdown && (
                <div
                  style={{
                    position: "absolute",
                    top: "calc(100% + 4px)",
                    right: 0,
                    backgroundColor: "#ffffff",
                    border: "1px solid #e5e7eb",
                    borderRadius: "10px",
                    boxShadow: "0 4px 16px rgba(0,0,0,0.08)",
                    zIndex: 30,
                    overflow: "hidden",
                    minWidth: "130px",
                  }}
                >
                  {TERMS.map((t) => (
                    <button
                      key={t}
                      onClick={() => { setTerm(t); setShowTermDropdown(false); }}
                      style={{
                        display: "block",
                        width: "100%",
                        padding: "8px 14px",
                        textAlign: "left",
                        border: "none",
                        backgroundColor: t === term ? "#eff6ff" : "transparent",
                        color: t === term ? "#1a56db" : "#374151",
                        fontSize: "0.8125rem",
                        fontWeight: t === term ? 600 : 400,
                        cursor: "pointer",
                      }}
                      onMouseOver={(e) => { if (t !== term) e.currentTarget.style.backgroundColor = "#f9fafb"; }}
                      onMouseOut={(e) => { if (t !== term) e.currentTarget.style.backgroundColor = "transparent"; }}
                    >
                      Term {t}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Notification bell */}
            <div style={{ position: "relative" }}>
              <button
                onClick={() => { setShowNotifications(!showNotifications); setShowTermDropdown(false); }}
                style={{
                  position: "relative",
                  width: "36px",
                  height: "36px",
                  borderRadius: "50%",
                  border: "1.5px solid #e5e7eb",
                  backgroundColor: "#f9fafb",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "#6b7280",
                }}
              >
                <Bell style={{ width: "16px", height: "16px" }} />
                {notifications > 0 && (
                  <span
                    style={{
                      position: "absolute",
                      top: "-3px",
                      right: "-3px",
                      width: "17px",
                      height: "17px",
                      borderRadius: "50%",
                      backgroundColor: "#ef4444",
                      color: "#fff",
                      fontSize: "0.6rem",
                      fontWeight: 700,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      border: "2px solid #fff",
                    }}
                  >
                    {notifications}
                  </span>
                )}
              </button>
              {showNotifications && (
                <div
                  style={{
                    position: "absolute",
                    top: "calc(100% + 6px)",
                    right: 0,
                    backgroundColor: "#ffffff",
                    border: "1px solid #e5e7eb",
                    borderRadius: "12px",
                    boxShadow: "0 8px 24px rgba(0,0,0,0.1)",
                    zIndex: 30,
                    width: "280px",
                    overflow: "hidden",
                  }}
                >
                  <div style={{ padding: "12px 16px", borderBottom: "1px solid #f3f4f6", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontWeight: 600, fontSize: "0.875rem", color: "#111827" }}>Notifications</span>
                    <span style={{ fontSize: "0.75rem", color: "#1a56db", cursor: "pointer", fontWeight: 500 }}>Mark all read</span>
                  </div>
                  {[
                    { title: "Exam scheduled", desc: "Math mid-term on Jul 5", time: "2h ago" },
                    { title: "Grade posted", desc: "Chemistry Lab: 87/100", time: "Yesterday" },
                    { title: "Payment due", desc: "Term fee due Jul 15", time: "2d ago" },
                  ].map((n, i) => (
                    <div
                      key={i}
                      style={{ padding: "10px 16px", borderBottom: i < 2 ? "1px solid #f9fafb" : "none", cursor: "pointer" }}
                      onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#f9fafb")}
                      onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
                    >
                      <div style={{ fontSize: "0.8125rem", fontWeight: 500, color: "#111827" }}>{n.title}</div>
                      <div style={{ fontSize: "0.75rem", color: "#6b7280", marginTop: "2px" }}>{n.desc}</div>
                      <div style={{ fontSize: "0.7rem", color: "#9ca3af", marginTop: "2px" }}>{n.time}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Avatar */}
            <div
              style={{
                width: "36px",
                height: "36px",
                borderRadius: "50%",
                backgroundColor: "#1a56db",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#fff",
                fontSize: "0.8rem",
                fontWeight: 700,
                cursor: "pointer",
                flexShrink: 0,
              }}
            >
              CM
            </div>
          </div>
        </header>

        {/* Page content via Outlet */}
        <main style={{ flex: 1, padding: "24px", display: "flex", flexDirection: "column", gap: "20px" }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
